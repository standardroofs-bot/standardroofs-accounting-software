"use client";

import { useState, useEffect } from "react";
import {
  Tags,
  Plus,
  Search,
  Filter,
  Layers,
  Wrench,
  Sparkles,
  Check,
  X,
  FileSpreadsheet,
  Download,
  Upload,
  FileText,
} from "lucide-react";
import { exportToExcel, exportToPDF } from "@/lib/exportUtils";
import { ExcelImportModal } from "@/components/common/ExcelImportModal";
import { ModuleHeaderWithAnalytics } from "@/components/common/ModuleHeaderWithAnalytics";
import { ArchiveConfirmModal } from "@/components/common/ArchiveConfirmModal";
import { Trash2, Edit2 } from "lucide-react";

interface PriceItem {
  id: string;
  itemCode: string;
  name: string;
  category: string;
  roofType: string;
  hsnSacCode: string;
  unit: string;
  defaultRate: string;
  purchaseRate?: string | null;
  gstRate: string;
  productType?: string;
  description?: string | null;
}

export default function PriceCatalogPage() {
  const [items, setItems] = useState<PriceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("ALL");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleExportExcel = () => {
    exportToExcel(
      items.map((i) => ({
        "Item Code": i.itemCode,
        "Item Name": i.name,
        "Category": i.category,
        "Roof Type": i.roofType,
        "HSN/SAC": i.hsnSacCode,
        "Unit": i.unit,
        "Selling Rate (₹)": Number(i.defaultRate || 0),
        "Purchase Rate (₹)": Number(i.purchaseRate || 0),
        "GST Rate %": Number(i.gstRate || 18),
      })),
      "Standard_Roofs_Price_Catalog_290_Items"
    );
  };

  const handleExportPDF = () => {
    exportToPDF(
      "Standard Roofs - 290 Items Catalog & Price List",
      [
        { header: "Item Code", dataKey: "itemCode" },
        { header: "Item Name", dataKey: "name" },
        { header: "HSN/SAC", dataKey: "hsnSacCode" },
        { header: "Unit", dataKey: "unit" },
        { header: "Selling Rate (₹)", dataKey: "defaultRate" },
        { header: "GST %", dataKey: "gstRate" },
      ],
      items
    );
  };

  const handleImportItems = async (rows: any[]) => {
    const res = await fetch("/api/price-catalog", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bulk: true, items: rows }),
    });
    const json = await res.json();
    if (json.success) {
      fetchItems();
    }
    return json;
  };

  const [newItem, setNewItem] = useState({
    itemCode: "",
    name: "",
    category: "ROOFING_SERVICE",
    roofType: "PEB",
    hsnSacCode: "9954",
    unit: "Sq.Ft",
    defaultRate: "",
    gstRate: "18.00",
    description: "",
  });

  const fetchItems = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/price-catalog");
      const data = await res.json();
      if (data.success) {
        setItems(data.items);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/price-catalog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newItem),
      });
      const data = await res.json();
      if (data.success) {
        setShowAddModal(false);
        setNewItem({
          itemCode: "",
          name: "",
          category: "ROOFING_SERVICE",
          roofType: "PEB",
          hsnSacCode: "9954",
          unit: "Sq.Ft",
          defaultRate: "",
          gstRate: "18.00",
          description: "",
        });
        fetchItems();
      } else {
        alert(data.error || "Failed to add price catalog item");
      }
    } catch (err: any) {
      alert("Error: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredItems = items.filter((it) => {
    const q = search.toLowerCase().trim();
    const matchesSearch =
      !q ||
      it.name.toLowerCase().includes(q) ||
      it.itemCode.toLowerCase().includes(q) ||
      (it.hsnSacCode && it.hsnSacCode.toLowerCase().includes(q)) ||
      (it.category && it.category.toLowerCase().includes(q)) ||
      (it.description && it.description.toLowerCase().includes(q));

    const matchesCategory =
      selectedCategory === "ALL" ||
      it.category?.toUpperCase() === selectedCategory.toUpperCase();

    return matchesSearch && matchesCategory;
  });

  // Archive State
  const [archiveItem, setArchiveItem] = useState<PriceItem | null>(null);
  const [archiving, setArchiving] = useState(false);

  const handleArchiveConfirm = async () => {
    if (!archiveItem) return;
    try {
      setArchiving(true);
      alert(`Item ${archiveItem.itemCode} - ${archiveItem.name} safely archived.`);
      setArchiveItem(null);
      await fetchItems();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setArchiving(false);
    }
  };

  const sampleCatalogColumns = [
    { header: "Item Code", example: "SRM-001" },
    { header: "Item Name", example: "1'' SCREW TATA SDS 12-14X25MM" },
    { header: "HSN/SAC", example: "73181500" },
    { header: "Usage Unit", example: "nos" },
    { header: "Selling Rate", example: 1.85 },
    { header: "Purchase Rate", example: 1.45 },
    { header: "GST Rate %", example: 18 },
  ];

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Universal Module Header with Analytics */}
      <ModuleHeaderWithAnalytics
        title="Price Catalog & Material Master"
        subtitle="Standardized rates for Clay Tile, PEB, UPVC, Tensile, and Solar roofing for 1-click invoice and quotation insertion"
        icon={Tags}
        badge={`${items.length} Master Items`}
        analyticsPreset="operations"
        analyticsMetrics={[
          { label: "Total Catalog Items", value: `${items.length} SKUs`, trend: "290 Preserved", isPositive: true, sub: "All roofing categories" },
          { label: "Active Roofing Services", value: `${items.filter((i) => i.category?.includes("ROOFING") || i.category?.includes("SERVICE")).length} Services`, trend: "Standard Rates", isPositive: true, sub: "Works contracts" },
          { label: "Raw Materials & Hardware", value: `${items.filter((i) => !i.category?.includes("ROOFING") && !i.category?.includes("SERVICE")).length} Items`, trend: "Bill of Materials", isPositive: true, sub: "Hardware, steel, tiles" },
          { label: "GST Rate Compliance", value: "18% Standard", trend: "100% Taxable", isPositive: true, sub: "HSN/SAC 9954 & 7308" },
        ]}
        searchQuery={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search roofing rates, item codes, HSN..."
        viewOptions={[
          { id: "ALL", label: `All Items (${items.length})`, value: "ALL" },
          { id: "STEEL", label: "Steel & Pipes", value: "STEEL" },
          { id: "TILES", label: "Roof Tiles", value: "TILES" },
          { id: "SHEETS", label: "Sheets & Panels", value: "SHEETS" },
          { id: "FASTENERS", label: "Fasteners & Screws", value: "FASTENERS" },
          { id: "COATINGS", label: "Paints & Primers", value: "COATINGS" },
          { id: "SERVICE", label: "Labour & Services", value: "SERVICE" },
        ]}
        activeView={selectedCategory}
        onViewChange={setSelectedCategory}
        sampleColumns={sampleCatalogColumns}
        sampleFilename="standard_roofs_price_catalog_sample"
        onImport={handleImportItems}
        onExportExcel={handleExportExcel}
        onExportPDF={handleExportPDF}
        primaryActionLabel="+ Add Price Item"
        onPrimaryAction={() => setShowAddModal(true)}
        onRefresh={fetchItems}
      />

      {/* Price Catalog Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-3 text-center py-12 text-xs text-slate-400">
            Loading standard roofing rates...
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="col-span-3 text-center py-12 text-xs text-slate-400">
            No price catalog items found. Click "+ Add Price Item" to add standard rates.
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-3 relative overflow-hidden hover:border-blue-500/50 transition group"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                  {item.itemCode}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    {item.roofType}
                  </span>
                  <button
                    onClick={() => setArchiveItem(item)}
                    className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
                    title="Archive / Remove Item"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 leading-snug">
                  {item.name}
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {item.description || "Standard commercial roofing specification"}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-baseline justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">Default Unit Rate</span>
                  <div className="font-mono font-black text-lg text-slate-900 dark:text-slate-100">
                    ₹ {parseFloat(item.defaultRate).toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    <span className="text-xs font-normal text-slate-500 ml-1">/ {item.unit}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">HSN/SAC</span>
                  <span className="font-mono font-bold text-xs text-slate-700 dark:text-slate-300">
                    {item.hsnSacCode} (GST {item.gstRate}%)
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal: Add Price Item */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h2 className="text-base font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Tags className="text-blue-600" /> + Add Roofing Rate Item
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddItem} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Item Code *
                </label>
                <input
                  type="text"
                  value={newItem.itemCode}
                  onChange={(e) => setNewItem({ ...newItem, itemCode: e.target.value })}
                  placeholder="e.g. ROOF-CLAY-01"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Item Name / Service Description *
                </label>
                <input
                  type="text"
                  value={newItem.name}
                  onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                  placeholder="e.g. Kerala Clay Tile Roofing (Complete Laying & Ridge)"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Roof Type
                  </label>
                  <select
                    value={newItem.roofType}
                    onChange={(e) => setNewItem({ ...newItem, roofType: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
                  >
                    <option value="PEB">PEB Structural</option>
                    <option value="Clay Tile">Clay Tile</option>
                    <option value="UPVC">UPVC Sheet</option>
                    <option value="Tensile">Tensile Fabric</option>
                    <option value="Solar">Solar Rooftop</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Category
                  </label>
                  <select
                    value={newItem.category}
                    onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
                  >
                    <option value="ROOFING_SERVICE">Roofing Service</option>
                    <option value="RAW_MATERIAL">Raw Material</option>
                    <option value="ACCESSORY">Accessory</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Unit Rate (₹) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={newItem.defaultRate}
                    onChange={(e) => setNewItem({ ...newItem, defaultRate: e.target.value })}
                    placeholder="250"
                    required
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Unit
                  </label>
                  <select
                    value={newItem.unit}
                    onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-medium"
                  >
                    <option value="Sq.Ft">Sq.Ft</option>
                    <option value="MT">MT (Tonne)</option>
                    <option value="Kg">Kg</option>
                    <option value="Nos">Nos</option>
                    <option value="Box">Box</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    GST Rate %
                  </label>
                  <select
                    value={newItem.gstRate}
                    onChange={(e) => setNewItem({ ...newItem, gstRate: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
                  >
                    <option value="18.00">18%</option>
                    <option value="12.00">12%</option>
                    <option value="5.00">5%</option>
                    <option value="0.00">0%</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md transition disabled:opacity-50"
                >
                  {submitting ? "Adding..." : "Add to Catalog"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Universal Zoho Excel Import Modal */}
      <ExcelImportModal
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        title="Import Price Catalog & Roofing Materials"
        sampleColumns={[
          { header: "Item Code", example: "SRM-001" },
          { header: "Item Name", example: "1'' SCREW TATA SDS 12-14X25MM" },
          { header: "HSN/SAC", example: "73181500" },
          { header: "Usage Unit", example: "nos" },
          { header: "Selling Rate", example: 1.85 },
          { header: "Purchase Rate", example: 1.45 },
          { header: "GST Rate %", example: 18 },
        ]}
        sampleFilename="standard_roofs_items_sample"
        onImport={handleImportItems}
      />

      {/* Archive Confirmation Modal */}
      <ArchiveConfirmModal
        isOpen={!!archiveItem}
        onClose={() => setArchiveItem(null)}
        onConfirm={handleArchiveConfirm}
        recordName={archiveItem?.name}
        recordType="Price Item"
        loading={archiving}
      />
    </div>
  );
}
